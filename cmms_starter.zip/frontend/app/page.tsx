export default function Page() {
  return (
    <div>
      <h1>لوحة التحكم (عينة)</h1>
      <p>واجهة مبدئية لعرض مؤشرات CMMS.</p>
    </div>
  )
}